/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import onlinemarketplacesystem.GUI.MainMenuCustomer;
import onlinemarketplacesystem.GUI.MainMenuSeller;

/**
 *
 * @author user
 */
public class Marketplace {

    /* 
    Marketplace class holds lists of customers, sellers, products, available products, 
    customer and seller menu(GUI), as well as methods to import CSVs from customer,seller and product files
     */
    private static ArrayList<Product> productList = new ArrayList<Product>();
    private static ArrayList<Product> availableProductList = new ArrayList<Product>();
    private static ArrayList<Customer> customerList = new ArrayList<Customer>();
    private static ArrayList<Seller> sellerList = new ArrayList<Seller>();
    private static User currentUser;
    private static int numOfThreads = 0;
    private static File customerFile = new File("Customers.csv");
    private static File sellerFile = new File("Sellers.csv");
    private static File productFile = new File("Products.csv");
    public static MainMenuCustomer customerMenu;
    public static MainMenuSeller sellerMenu;

    public static void importCSVs() throws InterruptedException, FileNotFoundException, IOException {
        /* 
        method to import CSVs from several files, such as customer,seller, and product files to the 
        arrays of objects, then imports to each entity(customer,seller) it's information.
         */
        Scanner scanner = new Scanner(productFile);
        if (scanner.hasNext()) {
            scanner.nextLine();
        }
        while (scanner.hasNext()) {
            String[] tokens = scanner.nextLine().split(",");
            productList.add(new Product(tokens));
        }
        
        
        
        scanner = new Scanner(customerFile);
        if (scanner.hasNext()) {
            scanner.nextLine();
        }
        while (scanner.hasNext()) {
            String[] tokens = scanner.nextLine().split(",");
            customerList.add(new Customer(tokens));
        }

        scanner = new Scanner(sellerFile);
        if (scanner.hasNext()) {
            scanner.nextLine();
        }
        while (scanner.hasNext()) {
            String[] tokens = scanner.nextLine().split(",");
            sellerList.add(new Seller(tokens));
        }

        scanner.close();
    }

    public static int distinctProductOccurence(ArrayList<Product> objList) {
        /* 
        returns the number of distinct products
         */
        ArrayList<Product> checkList = new ArrayList<Product>();
        for (Product obj : objList) {
            if (!checkList.contains(obj)) {
                checkList.add(obj);
            }
        }
        return checkList.size();
    }

    public static ArrayList<Seller> getSellerList() {
        // returns seller list
        return sellerList;
    }

    public static ArrayList<Customer> getCustomerList() {
        // returns customer list
        return customerList;
    }

    public static ArrayList<Product> getProductList() {
        // returns product list
        return productList;
    }

    public static ArrayList<Product> getAvailableProductList() {
        /* 
        returns list of available products that has a seller
         */
        availableProductList = new ArrayList<Product>();
        for (Product product : productList) {
            if (product.getSellerID() != 0 && !availableProductList.contains(product)) {
                availableProductList.add(product);
            }
        }
        return availableProductList;
    }

    public static void updateProductInformation(Product product, String name, String description, String category, float price, int quantity) {
        // updates products information, then updates that in the CSV file
        product.setCategory(category);
        product.setDescription(description);
        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);
        Product.updateProductCVS();
        Seller.updateSellerCVS();
    }

    public static void setCurrentUser(String type, int index) {
        // set's the current user to the user logged in and creates a new menu object for that user
        if (type.equals("Customer")) {
            System.out.println(index);
            currentUser = customerList.get(index - 1);
            customerMenu = new MainMenuCustomer((Customer) currentUser);
            OnlineMarketplaceSystem.loginMenu.setVisible(false);
            customerMenu.setVisible(true);
        } else if (type.equals("Seller")) {
            currentUser = sellerList.get(index - 1);
            sellerMenu = new MainMenuSeller((Seller) currentUser);
            OnlineMarketplaceSystem.loginMenu.setVisible(false);
            sellerMenu.setVisible(true);

        }
    }

    public static User getCurrentUser() {
        // returns current user
        return currentUser;
    }

    public static void addProduct(Product product) {
        // adds product to product list
        productList.add(product);
    }

    public static int calculateTotalBill() {
        // calculates total bill for the customer
        int bill = 0;
        for (int i = 0; i < ((Customer) currentUser).getShoppingCart().size(); i++) {
            bill += ((Customer) currentUser).getShoppingCart().get(i).getPrice();
        }
        return bill;
    }

    public static void transaction(float bill) throws InterruptedException {
        /* using multi-threading, allows for transactions to 
        occur after a delay of 50 ms times number of active threads
         */
            Thread thread = new Thread(new Transaction(currentUser, bill));
//            thread.wait(++numOfThreads * 50);
            thread.start();
            numOfThreads--;
            Product.updateProductCVS();
            Customer.updateCustomerCVS();
            Seller.updateSellerCVS();
        }
    }



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Seller extends User {

    /*
    A subclass of User, Seller Class is designed to store specific information regarding sellers.
    This class is provided with CSV writing capabilities, as well as CSV updating, to save information after
    a transaction has occured, as well as functional methods, such as: 
    adding/removing products to/from shopping cart, bought products lists, adding balance to seller.
     */
    private int sellerID;
    private float balance;
    private String username;
    private String password;
    private static int numOfSellers = 0;
    private ArrayList<Product> listOfProduce = new ArrayList<Product>();
    private static File sellersCSV = new File("Sellers.csv");
    private ArrayList<Integer> productIDs = new ArrayList<Integer>();

    public Seller(String[] tokens) {
        /* 
        Constructor that takes an array of tokens, each token represents personal data of sellers read
        from a CSV file.
         */
        
        super(tokens[1], tokens[2], tokens[3], Integer.valueOf(tokens[4]), tokens[5], tokens[6]);
        this.sellerID = Integer.valueOf(tokens[0]);
        this.username = tokens[1];
        this.password = tokens[2];
        this.balance = Float.valueOf(tokens[7]);
        ArrayList<Product> productList = Marketplace.getProductList();
        for (int i = 8; i < tokens.length; i++) {
            listOfProduce.add(productList.get(Integer.valueOf(tokens[i]) - 1));
            productIDs.add(Integer.valueOf(tokens[i]));
        }
    }

    public Seller(String username, String password, String name, int age, String address, String email) throws IOException {
        /*
        Constructor that takes inputted data to be set for seller, 
        then appends the new Seller data in CSV file.
         */
       
        super(username, password, name, age, address, email);
        this.username = username;
        this.password = password;
        try ( PrintWriter writer = new PrintWriter(new FileWriter(sellersCSV, true))) {
            numOfSellers = Marketplace.getSellerList().size();
            sellerID = ++numOfSellers;
            writer.append("\n" + sellerID + "," + username + "," + password
                    + "," + name + "," + age + "," + address + "," + email + "," + balance + ",");
            writer.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
            return;
        }
    }

    public ArrayList<Product> getListOfProduce() {
        // returns sellers list of product
        return listOfProduce;
    }

    public ArrayList<Integer> getProductIDs() {
        // returns list of seller's listed products IDS
        return productIDs;
    }

    public int getSellerID() {
        // returns seller's ID
        return sellerID;
    }

    public void printListOfProduce() {
        // prints seller's list of products
        int x = 1;
        for (Product product : listOfProduce) {
            System.out.println(x++ + ": " + product);
        }
    }

    public void addProduct(Product product) {
        // adds product to seller's list of products
        listOfProduce.add(product);
        productIDs.add(product.getProductID());
    }

    public void addBalance(float profit) {
        // adds to sellers balance after a transaction occured
        this.balance += profit;
    }

    public void removeProduce(Product product) {
        // removes product from seller's list of products and list of product IDS
        for (int i = 0; i < productIDs.size(); i++) {
            if (product.getProductID() == productIDs.get(i)) {
                productIDs.remove(i);
                break;
            }
        }
        listOfProduce.remove(product);

    }

    public void printInfo() {
        // prints information about the seller
        System.out.println("Personal Information\nName: " + super.getName()
                + "\nAge: " + super.getAge() + "\nAddress: " + super.getAddress()
                + "\nEmail: " + super.getEmail() + "\nNumber of listed produce: " + listOfProduce.size());
    }

    public static void updateSellerCVS() {
        // updates the seller CVS by rewriting the file
        
        
        ArrayList<Seller> sellerList = Marketplace.getSellerList();
        try ( PrintWriter writer = new PrintWriter(sellersCSV)) {
            writer.println("sellerID,username,password,name,age,address,email,balance,productID");
            System.out.println("Seller list size: " + sellerList.size());
            for (Seller seller : sellerList) {
                writer.print(seller.sellerID + "," + seller.username + "," + seller.password
                        + "," + seller.getName() + "," + seller.getAge() + "," + seller.getAddress()
                        + "," + seller.getEmail() + "," + seller.balance);
                for (Integer productID : seller.productIDs) {
                    writer.print("," + productID);
                }
                writer.println();
            }
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

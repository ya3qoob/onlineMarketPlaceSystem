/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Customer extends User {

    /*
    A subclass of User, Customer Class is designed to store specific information regarding customers
    This class is provided with CSV writing capabilities, as well as CSV updating, to save information after
    a transaction has occured, as well as functional methods, such as: 
    adding/removing products to/from shopping cart, bought products lists, adding balance to customer.
     */
    private int customerID;
    private String password;
    private String username;
    private static int numOfCustomers = 0;
    private ArrayList<Product> shoppingCart = new ArrayList<Product>();
    private ArrayList<Product> boughtProducts = new ArrayList<Product>();
    private float balance;
    private ArrayList<Integer> productIDs = new ArrayList<Integer>();

    private static File customersCSV = new File("Customers.csv");

    public Customer(String[] tokens) {
        /* 
        Constructor that takes an array of tokens, each token represents personal data of customers read
        from a CSV file.
         */
        super(tokens[1], tokens[2], tokens[3], Integer.valueOf(tokens[4]), tokens[5], tokens[6]);
        this.customerID = Integer.valueOf(tokens[0]);
        this.username = tokens[1];
        this.password = tokens[2];
        this.balance = Float.valueOf(tokens[7]);
        ArrayList<Product> productList = Marketplace.getProductList();
        for (int i = 8; i < tokens.length; i++) {
            this.boughtProducts.add(productList.get(Integer.valueOf(tokens[i]) - 1));
            productIDs.add(Integer.valueOf(tokens[i]));
        }
    }

    public Customer(String username, String password, String name, int age, String address, String email) throws IOException {
        /*
        Constructor that takes inputted data to be set for customer, 
        then appends the new customer data in CSV file.
         */
        super(username,password,name,age,address,email);
        try ( PrintWriter writer = new PrintWriter(new FileWriter(customersCSV, true))) {
            Scanner scanner = new Scanner(customersCSV);
            if (scanner.hasNext()) {
                scanner.nextLine();
                numOfCustomers = Marketplace.getCustomerList().size();
            } else {
                System.out.println("Empty");
            }
            customerID = ++numOfCustomers;
            writer.append("\n" + customerID + "," + username + "," + password
                    + "," + name + "," + age + "," + address + "," + email + "," + balance + ",");
            for (int productID : productIDs) {
                writer.append(String.valueOf(productID));
            }
            writer.close();
            scanner.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
            return;
        }
    }

    public ArrayList<Product> getBoughtProducts() {
        // returns customer's bought products
        return boughtProducts;
    }

    public void setBoughtProducts(ArrayList<Product> boughtProducts) {
        // sets the customer's bought products
        this.boughtProducts = boughtProducts;
    }

    public float getBalance() {
        // returns customer's balance
        return this.balance;
    }

    public int getCustomerID() {
        // returns customer's unique ID
        return customerID;
    }

    public void setBalance(float balance) {
        // sets the customer's balance
        this.balance = balance;
    }

    @Override
    public void printInfo() {
        // prints information of user
        System.out.println("Personal Information\nName: " + super.getName()
                + "\nAge: " + super.getAge() + "\nAddress: " + super.getAddress()
                + "\nEmail: " + super.getEmail());
    }

    public void printShoppingCart() {
        // prints a list of customer's shopping cart
        int x = 1;
        for (Product product : shoppingCart) {
            System.out.println(x++ + ": " + product);
        }
    }

    public ArrayList<Product> getShoppingCart() {
        // returns customer's shopping cart
        return shoppingCart;
    }

    public void addBalance(float topUp) {
        // top-ups the customer's balance and updates the customer CSV
        balance += topUp;
        Customer.updateCustomerCVS();
        System.out.println(balance);
    }

    public void subtractBalance(float bill) {
        // subtracts the bill from customer's balance
        balance -= bill;
    }

    public void addProduct(Product product) {
        // adds product to customer's shopping cart
        shoppingCart.add(product);
    }

    public void addBoughtProduct(Product product) {
        // adds bought products from shopping cart to bought products list
        boughtProducts.add(product);
        productIDs.add(product.getProductID());
    }

    public void removeProduct(Product product) {
        // removes a product from customer's shopping cart
        shoppingCart.remove(product);
    }

    public ArrayList<Integer> getProductIDs() {
        // returns list of productIDs that have been bought
        return productIDs;
    }

    public static void updateCustomerCVS() {
        // rewrites the customer CSV file with all the new changes
        ArrayList<Customer> customerList = Marketplace.getCustomerList();
        try ( PrintWriter writer = new PrintWriter(customersCSV)) {
            writer.println("customerID,username,password,name,age,address,email,balance,productID");
            System.out.println("Customer list size: " + customerList.size());
            for (Customer customer : customerList) {
                writer.print(customer.customerID + "," + customer.username + "," + customer.password
                        + "," + customer.getName() + "," + customer.getAge() + "," + customer.getAddress()
                        + "," + customer.getEmail() + "," + customer.balance);
                for (Integer productID : customer.productIDs) {
                    writer.print("," + productID);
                }
                writer.println();
            }
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

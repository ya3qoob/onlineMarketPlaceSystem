/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package onlinemarketplacesystem;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface IProductSearch {
// interface to implement several search methods, (name,category,price,seller)

    public abstract ArrayList<Product> searchName(String name);

    public abstract ArrayList<Product> searchCategory(String category);

    public abstract ArrayList<Product> searchPrice(float lowerLimit, float upperLimit);

    public abstract ArrayList<Product> searchSeller(String sellerName);
}

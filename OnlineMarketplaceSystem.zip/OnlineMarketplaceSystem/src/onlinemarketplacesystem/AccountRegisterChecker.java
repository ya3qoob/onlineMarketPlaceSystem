/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class AccountRegisterChecker implements Runnable {
// A class designed to check if the entered username exists within a CSV file

    private File importedFile;
    private String username;
    public boolean foundAccount;

    public AccountRegisterChecker(File importedFile, String username) {
        // Constructor to set the file and username
        this.importedFile = importedFile;
        this.username = username;
    }

    @Override
    public void run() {
        /* method allows the thread to check if a username exists within a file, if found it will set 
        foundAccount true
            
         */
        try ( Scanner fileScanner = new Scanner(importedFile)) {
            System.out.println(fileScanner.hasNextLine());
            if (fileScanner.hasNextLine()) {
                fileScanner.nextLine();
            }
            if (fileScanner.hasNext()) {
                do {
                    String[] tokens = fileScanner.nextLine().split(",");
                    System.out.println(tokens[1]);
                    if (tokens[1].equals(username)) {
                        System.out.println("Found username");
                        foundAccount = true;
                        return;
                    }
                } while (fileScanner.hasNextLine());
            } else {
                System.out.println("Empty line.");
            }
        } catch (FileNotFoundException x) {
        }
    }

}

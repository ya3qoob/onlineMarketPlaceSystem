/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Product {

    /*
    Product class is designed to store information about products. 
    This class includes CSV writing and importing capabilities that allows for data storage.
     */
    private int productID;
    private int sellerID;
    private String category;
    private String name;
    private String description;
    private float price;
    private int quantity;
    private static int numOfObjects = 0;
    private static String dir = System.getProperty("user.dir");
    private static File productCSV = new File("Products.csv");

    public Product(String name, String description, String category, float price, int quantity, int sellerID) throws IOException {
        /*
        Contructor that sets products information, then appends it in a CSV file
        */
        this.name = name;
        this.description = description;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.sellerID = sellerID;

        try ( PrintWriter writer = new PrintWriter(new FileWriter(productCSV, true))) {
            numOfObjects = Marketplace.getProductList().size();
            this.productID = ++numOfObjects;
            writer.append("\n" + productID + "," + name + "," + description + "," + category
                    + "," + price + "," + quantity + "," + sellerID);
            writer.close();
            Seller.updateSellerCVS();
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
    }

    public Product(String name, String category, float price, int quantity, int sellerID) throws IOException {
        /*
        Contructor that sets products information excluding description, then appends it in a CSV file
        */
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.sellerID = sellerID;

        try ( PrintWriter writer = new PrintWriter(new FileWriter(productCSV, true))) {
            numOfObjects = Marketplace.getProductList().size();
            this.productID = ++numOfObjects;
            writer.append("\n" + productID + "," + name + "," + description + "," + category
                    + "," + price + "," + quantity + "," + sellerID);
            writer.close();
            Seller.updateSellerCVS();
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
            return;
        }

    }

    public void setSellerID(int sellerID) {
        // returns seller ID
        this.sellerID = sellerID;
    }

//    public Product() {
//        // allows the creation of an empty product
//    }

    public String getCategory() {
        // returns category of product
        return category;
    }

    public void setCategory(String category) {
        // sets the category of product
        this.category = category;
    }

    public Product(String[] tokens) {
        /* 
        Constructor that takes an array of tokens, each token represents personal data of products read
        from a CSV file.
         */
        this.productID = Integer.valueOf(tokens[0]);
        this.name = tokens[1];
        this.description = tokens[2];
        this.category = tokens[3];
        this.price = Float.valueOf(tokens[4]);
        this.quantity = Integer.valueOf(tokens[5]);
        this.sellerID = Integer.valueOf(tokens[6]);
    }

    public int getSellerID() {
        // returns seller ID of product
        return sellerID;
    }

    public void decrementQty() {
        // decrements quantity of product
        --this.quantity;
    }

    public int getProductID() {
        // returns product ID
        return productID;
    }

    public String getName() {
        // returns product name
        return name;
    }

    public void setName(String name) {
        // sets product name
        this.name = name;
    }

    public String getDescription() {
        // returns description of product
        return description;
    }

    public void setDescription(String description) {
        // sets the description of product
        this.description = description;
    }

    public float getPrice() {
        // returns price of product
        return price;
    }

    public void setPrice(float price) {
        // sets price of product
        this.price = price;
    }

    public int getQuantity() {
        // returns quantity of product
        return quantity;
    }

    public void setQuantity(int quantity) {
        // sets quantity of product
        this.quantity = quantity;
    }

    public void printInfo() {
        // prints information of product in console
        System.out.println("Name: " + name + ", ProductID: " + productID + ", Price: " + price
                + ", Quantity: " + quantity + ", Description: " + description);
    }

    public String toString() {
        // returns information about product
        return "Name: " + name + ", ProductID: " + productID + ", Price: " + price;
    }

    public static void updateProductCVS() {
        // updates the product CSV by rewriting it
        ArrayList<Product> productList = Marketplace.getProductList();
        try ( PrintWriter writer = new PrintWriter(productCSV)) {
            writer.println("productID,name,description,category,price,quantity,sellerID");
            System.out.println("Products list size: " + productList.size());
            for (Product product : productList) {
                writer.println(product.productID + "," + product.name + "," + product.description
                        + "," + product.category + "," + product.price + "," + product.quantity
                        + "," + product.sellerID);

            }
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

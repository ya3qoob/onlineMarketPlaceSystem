/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

/**
 *
 * @author user
 */
import java.util.*;
import java.io.*;

public abstract class User implements Comparable {

    /*
    An abstract superclass , User Class is designed to store basic information about users.
    Equipped with static methods that check if user successfully logins or registers.
     */
        static Thread[] threads = new Thread[2];
    private String name;
    private int age;
    private String username;
    private String password;
    private String address;
    private String email;
    private float balance;

    public User(String username, String password, String name, int age, String address, String email) {
        // contructor to set user's information
        this.username = username;
        this.password = password;
        this.name = name;
        this.age = age;
        this.address = address;
        this.email = email;
    }

    public float getBalance() {
        // returns user's balance
        return balance;
    }

    public void setBalance(float balance) {
        // sets user's balance
        this.balance = balance;
    }

    public String getName() {
        // returns user's name
        return name;
    }

    public void setName(String name) {
        // sets the user's name
        this.name = name;
    }

    public int getAge() {
        // returns user's age
        return age;
    }

    public void setAge(int age) {
        // sets user's age
        this.age = age;
    }

    public String getAddress() {
        // returns user's address
        return address;
    }

    public void setAddress(String address) {
        // sets user's address
        this.address = address;
    }

    public String getEmail() {
        // returns user's email
        return email;
    }

    public void setEmail(String email) {
        // sets user's email
        this.email = email;
    }

    public static Boolean register(String username) throws InterruptedException, IncorrectIdentificationException {
        // method that checks if a username exists in customer/seller CSV file
        System.out.println("Checking username");
        File customerFile = new File("Customers.csv");
        File sellerFile = new File("Sellers.csv");
        AccountRegisterChecker[] accounts = new AccountRegisterChecker[2];
        accounts[0] = new AccountRegisterChecker(customerFile, username);
        accounts[1] = new AccountRegisterChecker(sellerFile, username);
        threads[0] = new Thread(accounts[0]);
        threads[0].start();
        threads[0].join();
        threads[1] = new Thread(accounts[1]);
        threads[1].start();

        if (accounts[0].foundAccount || accounts[1].foundAccount) {
            throw new IncorrectIdentificationException("Username taken.");
        }
        return true;
    }

    public static User login(String username, String password) throws InterruptedException, IOException {
        // method that checks if username and password are matching an existing user's then returns the user
        ArrayList<Seller> sellerList = Marketplace.getSellerList();
        ArrayList<Customer> customerList = Marketplace.getCustomerList();
        for (Customer customer : customerList) {
            if (customer != null && customer.getUsername().equals(username) && customer.compareTo(password) == 1) {
                Marketplace.setCurrentUser("Customer", customer.getCustomerID());
                return Marketplace.getCurrentUser();
            }
        }
        for (Seller seller : sellerList) {
            if (seller != null && seller.getUsername().equals(username) && seller.compareTo(password) == 1) {
                Marketplace.setCurrentUser("Seller", seller.getSellerID());
                return Marketplace.getCurrentUser();
            }
        }
        return null;
    }

    @Override
    public int compareTo(Object o) {
        if (this.password.equals(o)) {
            return 1;
        } else {
            return 0;
        }
    }

    public String getUsername() {
        return username;
    }

    public abstract void addProduct(Product product);

    public abstract void printInfo();

}

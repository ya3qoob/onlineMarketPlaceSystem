/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

/**
 *
 * @author user
 */
public class Transaction implements Runnable {
    /*
    Transaction class that allows thread to run and compute transactions
    */
    private User currentUser;
    private float bill;
    
    Transaction(User currentUser, float bill) {
        // constructor that takes current user and bill
        this.currentUser = currentUser;
        this.bill = bill;
    }
    
    public void run() {
        // allows thread to compute transaction
        for (Product shoppingCart : ((Customer) currentUser).getShoppingCart()) {
            shoppingCart.decrementQty();
            ((Customer) currentUser).addBoughtProduct(shoppingCart);
            Marketplace.getSellerList().get(shoppingCart.getSellerID() - 1).addBalance(shoppingCart.getPrice());
        }
        ((Customer) currentUser).getShoppingCart().clear();
        ((Customer) currentUser).subtractBalance(bill);
    }
}

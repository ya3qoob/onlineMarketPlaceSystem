/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class ProductSearchEngine implements IProductSearch, Runnable {

    /*
    A class extending from IProductSearch interface, implements several searching methods that returns a
    an array of found products.
     */
    private ArrayList<Product> productList = Marketplace.getAvailableProductList();
    private ArrayList<Product> foundProducts;
    private String type;
    private String searchTerm;
    private float min;
    private float max;

    public ProductSearchEngine() {
    }

    public ProductSearchEngine(String type, String searchTerm) {
        this.type = type;
        this.searchTerm = searchTerm;
    }

    public ProductSearchEngine(String type, float min, float max) {
        this.type = type;
        this.min = min;
        this.max = max;
    }

    public ProductSearchEngine(String type, ArrayList<Product> productList, String searchTerm) {
        this.type = type;
        this.productList = productList;
        this.searchTerm = searchTerm;
    }

    public ProductSearchEngine(String type, ArrayList<Product> productList, float min, float max) {
        this.type = type;
        this.productList = productList;
        this.min = min;
        this.max = max;
    }

    public ProductSearchEngine(ArrayList<Product> productList) {
        this.productList = productList;
    }

    @Override
    public ArrayList<Product> searchName(String name) {
        /*
        Method that searches for each token received from the searchAlgorithm is contained
        in the product list, does not include duplicates of products
         */
        foundProducts = new ArrayList<Product>();
        ArrayList<String> tokens = searchAlgorithm(name.toLowerCase());
        for (String token : tokens) {
            for (Product product : productList) {
                if (product.getName().toLowerCase().contains(token) && !foundProducts.contains(product)) {
                    foundProducts.add(product);
                }
            }
        }
        return this.foundProducts;
    }

    @Override
    public ArrayList<Product> searchCategory(String category) {
        /*
        Method that searches for each token received from the searchAlgorithm is contained
        in the product list, does not include duplicates of products
         */
        foundProducts = new ArrayList<Product>();
        ArrayList<String> tokens = searchAlgorithm(category.toLowerCase());
        for (String token : tokens) {
            for (Product product : productList) {
                if (product.getCategory().toLowerCase().contains(token) && !foundProducts.contains(product)) {
                    foundProducts.add(product);
                }
            }
        }
        return this.foundProducts;
    }

    @Override
    public ArrayList<Product> searchPrice(float lowerLimit, float upperLimit) {
        /*
        Method that searches for each token received from the searchAlgorithm is contained
        in the product list, does not include duplicates of products
         */
        foundProducts = new ArrayList<Product>();
        for (Product product : productList) {
            if (product.getPrice() >= lowerLimit && product.getPrice() <= upperLimit) {
                foundProducts.add(product);
            }
        }
        return this.foundProducts;
    }

    @Override
    public ArrayList<Product> searchSeller(String sellerName) {
        /*
        Method that searches for each token received from the searchAlgorithm is contained
        in the product list, does not include duplicates of products
         */
        ArrayList<Seller> sellerList = Marketplace.getSellerList();
        foundProducts = new ArrayList<Product>();
        ArrayList<String> tokens = searchAlgorithm(sellerName.toLowerCase());
        for (String token : tokens) {
            for (Product product : productList) {
                if (sellerList.get(product.getSellerID() - 1).getName().toLowerCase().contains(token)
                        && !foundProducts.contains(product)) {
                    foundProducts.add(product);
                }
            }
        }
        return this.foundProducts;
    }

    public ArrayList<String> searchAlgorithm(String input) {
        /* 
        a search algorithm that splits the string into several tokens/pieces such taht it can be used to
        check if they are contained inside the product list in search methods.
         */
        String[] firstSplitTokens = input.split(" ");
        ArrayList<String> secondSplitTokens = new ArrayList<String>();
        for (int i = 0; i < firstSplitTokens.length; i++) {
            if (firstSplitTokens[i].length() >= 6 && firstSplitTokens[i].length() < 9) {
                secondSplitTokens.add(firstSplitTokens[i].substring(0, (int) firstSplitTokens[i].length() / 2));
                secondSplitTokens.add(firstSplitTokens[i].substring(0, firstSplitTokens[i].length()));
            } else if (firstSplitTokens[i].length() >= 9) {
                secondSplitTokens.add(firstSplitTokens[i].substring(0, (int) firstSplitTokens[i].length() / 3));
                secondSplitTokens.add(firstSplitTokens[i].substring(0, firstSplitTokens[i].length()));
            } else if (firstSplitTokens[i].length() >= 4) {
                secondSplitTokens.add(firstSplitTokens[i].substring(0, 3));
                secondSplitTokens.add(firstSplitTokens[i].substring(1, firstSplitTokens[i].length()));
            } else {
                secondSplitTokens.add(firstSplitTokens[i].substring(0));
            }
        }
        secondSplitTokens.add(input);
        return secondSplitTokens;
    }

    public ArrayList<Product> getFoundProducts() {
        return foundProducts;
    }

    @Override
    public void run() {
        if (this.type.equals("Name")) {
            searchName(searchTerm);
        } else if (this.type.equals("Category")) {
            searchCategory(searchTerm);
        } else if (this.type.equals("Price")) {
            searchPrice(min, max);
        } else if (this.type.equals("Seller")) {
            searchSeller(searchTerm);
        }

    }
}

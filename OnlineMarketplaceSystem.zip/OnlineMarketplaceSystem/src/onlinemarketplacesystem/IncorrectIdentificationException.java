/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

/**
 *
 * @author user
 */
public class IncorrectIdentificationException extends Exception {
// Exception when user enters wrong username/password

    public IncorrectIdentificationException(String message) {
        super(message);
    }

    public IncorrectIdentificationException() {
        this("Incorrect Identification.");
    }

}

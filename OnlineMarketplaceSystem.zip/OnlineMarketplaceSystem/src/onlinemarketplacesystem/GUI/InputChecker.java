/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem.GUI;

/**
 *
 * @author user
 */
public class InputChecker {
// input checker for letters and numbers
    public static boolean isAllLetters(String input) {
        // loops through the the string character by character to check if its all letters
        for (int i = 0; i < input.length(); i++) {
            if (Character.isLetter(input.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAllNumbers(String input) {
        // loops through the the string character by character to check if its all numbers
        for (int i = 0; i < input.length(); i++) {
            if (Character.isDigit(input.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinemarketplacesystem;

/**
 *
 * @author user
 */
public class OutOfStockException extends Exception {
// Custom exception for out of stock occurences.

    public OutOfStockException(String message) {
        super(message);
    }

    public OutOfStockException() {
        this("Out of Stock.");
    }

}
